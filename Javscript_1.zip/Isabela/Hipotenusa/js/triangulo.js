var valor1 = parseFloat(prompt("digita el valor1"))
var valor2 = parseFloat(prompt("digita el valor2"))
var resultado = 0

resultado = Math.sqrt ((valor1*valor1) + (valor2*valor2))
console.log ("el resultado de la hipotenusa es: " + resultado)