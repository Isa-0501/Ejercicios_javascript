var temperatura = parseFloat(prompt("digita la temperatura en farenheit"))
var resultado = 0

resultado = (temperatura - 32) * (5/9)
console.log("el resultado en centigrados es: " + resultado + "°C") 