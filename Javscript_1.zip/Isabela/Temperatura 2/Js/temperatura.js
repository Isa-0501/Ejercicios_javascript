var temperatura  = parseFloat(prompt("digita la temperatura en celsius"))
var resultado = 0

resultado = (temperatura * (9/5) + 32) 
console.log ("el resultado en fahrenheit es: " + resultado + "°F") 