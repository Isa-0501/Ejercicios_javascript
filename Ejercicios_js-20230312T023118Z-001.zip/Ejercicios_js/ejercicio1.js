var altura = parseInt (prompt("digita la altura"))

if (altura <= 150) {
    console.log ("persona de altura baja")
}else{ 
    if (altura >= 151) {
        if (altura <= 170){
            console.log ("persona de altura media")
        }else{
            console.log ("persona alta")
        }       
    } 
}