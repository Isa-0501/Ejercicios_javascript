var matematicas = parseInt (prompt("digita la nota matematicas"))
var español = parseInt (prompt("digita la nota español")) 
var sociales = parseInt (prompt("digita la nota sociales"))
var promedio = 0

promedio = (matematicas + español + sociales)/3
console.log ("el promedio es: "+ promedio)

if (promedio == 10) {
    console.log ("Excelente")
}else{
    if (promedio >= 7){
        if (promedio < 10){
            console.log ("Bueno")
        }
    }else{
        if (promedio < 7){
            console.log ("Insuficiente")
        }
    }
}