var altura = parseInt (prompt("digita la altura"))

if (altura <= 150) {
    console.log ("persona de altura baja")
}