var peras = parseInt (prompt ("precio de la pera = 1500, digita la cantidad de peras"))
var totalperas = 0
var mangos = parseInt (prompt ("precio del mango = 2000, digita la cantidad de mangos"))
var totalmangos = 0
var manzanas = parseInt (prompt ("precio de la manzana = 1800, digita cantidad de manzanas"))
var totalmanzanas = 0
var bananos = parseInt (prompt ("precio del banano = 500, digita la cantidad de bananos"))
var totalbananos = 0
var sandias = parseInt (prompt ("precio de la sandia = 5000, digita la cantidad de sandias"))
var totalsandias = 0
var kiwis = parseInt (prompt ("precio del kiwi = 1000, digita la cantidad de kiwis"))
var totalkiwis = 0
var total = 0
var totalcantidadcomprada = 0

if (peras >= 0){
    totalperas = peras * 1500
}if (mangos >= 0){
    totalmangos = mangos * 2000
}if (manzanas >= 0){
    totalmanzanas = manzanas * 1800
}if (bananos >= 0){
    totalbananos = bananos * 500
}if (sandias >= 0){
    totalsandias = sandias * 5000
}if (kiwis >= 0){
    totalkiwis = kiwis * 1000
}

total = totalperas + totalmangos + totalmanzanas + totalbananos + totalsandias + totalkiwis
{alert (total + totalcantidadcomprada)}