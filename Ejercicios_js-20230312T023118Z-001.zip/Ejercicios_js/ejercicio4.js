var escritorio = 100000
var cantidad = parseInt (prompt("Digite la cantidad de escritorios"))
var resultado = 0

if (cantidad < 5) {
    resultado = (escritorio - (escritorio * 0.1)) * cantidad
    console.log ("total a pagar " + resultado)
}else{
    if (cantidad >= 5){
        if (cantidad < 10){
            resultado = (escritorio - (escritorio * 0.2)) * cantidad
            console.log ("total a pagar " + resultado)
        }
}
    if (cantidad >= 10){
        resultado = (escritorio - (escritorio * 0.4)) * cantidad
        console.log("total a pagar" + resultado)
    }
}