var estatura = parseInt (prompt("digita la estatura"))
var velocidad= parseInt (prompt("digita la velocidad"))
var edad = parseInt (prompt("digita la edad"))

if (estatura >= 175){
    if (velocidad >= 100 ){
        if (edad < 18)
        console.log ("Puede ingresar al equipo")
        console.log ("Ingresa a la liga de menores")
    }
}else{
    if (estatura < 175){        
        console.log ("No puede ingresar al equipo")        
    }
}